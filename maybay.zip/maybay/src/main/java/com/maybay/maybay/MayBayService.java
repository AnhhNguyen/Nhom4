package com.maybay.maybay;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;
import org.springframework.stereotype.Service;




@Service
public class MayBayService {

	@Autowired
	MayBayDao service;
	//1 get all thong tin xe
	public List<MayBay2> getThongTinMayBay(Integer mave) {
		List<MayBay2> mayBay2 = new ArrayList<>();
		List<MayBay> mayBay = ((MayBayDao) service).findAll();
		
		for (int i = 0; i < mayBay.size(); i++) {
			MayBay2 tx = new MayBay2();
			tx.setMave(mayBay.get(i).getMave());
			tx.setGiatien(mayBay.get(i).getGiatien());
			tx.setGioden(mayBay.get(i).getGioden());
			tx.setGiodi(mayBay.get(i).getGiodi());
			tx.setNgaydi(mayBay.get(i).getNgaydi());
			tx.setNoiden(mayBay.get(i).getNoiden());
			tx.setNoidi(mayBay.get(i).getNoidi());
			tx.setSoghe(mayBay.get(i).getSoghe());
			tx.setThoigiandi(mayBay.get(i).getGioden() - mayBay.get(i).getGiodi() );;
			
			mayBay2.add(tx);
		}
		return mayBay2;
		
	}
	//
	
		//xoa 1 chuyeens theo ma
		public void deleteMayBayByMaxe(Integer integer) {
			MayBay mayBay = new MayBay();
			mayBay.setMave(integer);
			ExampleMatcher exampleMatcher = ExampleMatcher.matching()
					.withIgnorePaths("noidi")
					.withIgnorePaths("noiden")
					.withIgnorePaths("ngaydi")
					.withIgnorePaths("giodi")
					.withIgnorePaths("gioden")
					.withIgnorePaths("giatien")
					.withIgnorePaths("soghe");
			List<MayBay> veTaus = service.findAll(Example.of(mayBay, exampleMatcher));
			//delete
			service.delete(veTaus);
			
		}
		//delete nhieu chuyen thoe ngay
		public void deleteManyMayBayByNgay(MayBay mayBay) {
			ExampleMatcher exampleMatcher = ExampleMatcher.matching()
					.withIgnorePaths("maVe")
					.withIgnorePaths("noiDi")
					.withIgnorePaths("noiDen")		
					.withIgnorePaths("gioDi")
					.withIgnorePaths("gioDen")
					.withIgnorePaths("giaTien")
					.withIgnorePaths("soGhe");
			List<MayBay> mayBays = service.findAll(Example.of(mayBay,exampleMatcher));
			service.delete(mayBays);
		}
		
		//update
		public MayBay getOneMayBayByMave(Integer mave) {
			return service.findOne(mave);
		}

		public void updateOneMayBay(MayBay MayBay) {
			service.save(MayBay);
		}
		//
		public List<MayBay> SearchDate(String ngaydi, String noidi,String noiden) {
			MayBay tx = new MayBay();
			tx.setNgaydi(ngaydi);

			ExampleMatcher ex = ExampleMatcher.matching().withIgnorePaths("maVe").withIgnorePaths("gioDi").withIgnorePaths("gioDen").withIgnorePaths("giaTien")
					.withIgnorePaths("soGhe");
			return service.findAll(Example.of(tx, ex));
		}

		public List<MayBay> getall() {
			// TODO Auto-generated method stub
			return null;
		}
		//e. tìm kiếm các thực thể theo 1 lúc 2 thuộc tính ví dụ: tenSV, diaChi(tên và địa chỉ giống nhau)
		public List<MayBay> searchMayBayTheoMave(Integer maVe) {
			MayBay mayBay = new MayBay();
			mayBay.setMave(maVe);
			ExampleMatcher exampleMatcher = ExampleMatcher.matching().withIgnorePaths("maVe").withIgnorePaths("gioDi")
					.withIgnorePaths("gioDen").withIgnorePaths("giaTien").withIgnorePaths("soGhe");
			List<MayBay> mayBays = service.findAll(Example.of(mayBay, exampleMatcher));
			return mayBays;
		}
		
}

