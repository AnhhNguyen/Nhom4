package com.maybay.maybay;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;

@Transactional
	public interface MayBayDao extends JpaRepository<MayBay, Integer> {
}

