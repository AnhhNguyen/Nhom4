package com.maybay.maybay;

public class MayBay2 {
	public Integer mave;
	public String noidi;
	public String noiden;
	public String ngaydi;
	public Integer giodi;
	public Integer gioden;
	public String giatien;
	public Integer soghe;
	public Integer thoigiandi;
	
	
	public MayBay2() {
		super();
	}
	public MayBay2(Integer mave, String noidi, String noiden, String ngaydi, Integer giodi, Integer gioden,
			String giatien, Integer soghe, Integer thoigiandi) {
		super();
		this.mave = mave;
		this.noidi = noidi;
		this.noiden = noiden;
		this.ngaydi = ngaydi;
		this.giodi = giodi;
		this.gioden = gioden;
		this.giatien = giatien;
		this.soghe = soghe;
		this.thoigiandi = thoigiandi;
	}
	public Integer getMave() {
		return mave;
	}
	public void setMave(Integer mave) {
		this.mave = mave;
	}
	public String getNoidi() {
		return noidi;
	}
	public void setNoidi(String noidi) {
		this.noidi = noidi;
	}
	public String getNoiden() {
		return noiden;
	}
	public void setNoiden(String noiden) {
		this.noiden = noiden;
	}
	public String getNgaydi() {
		return ngaydi;
	}
	public void setNgaydi(String ngaydi) {
		this.ngaydi = ngaydi;
	}
	public Integer getGiodi() {
		return giodi;
	}
	public void setGiodi(Integer giodi) {
		this.giodi = giodi;
	}
	public Integer getGioden() {
		return gioden;
	}
	public void setGioden(Integer gioden) {
		this.gioden = gioden;
	}
	public String getGiatien() {
		return giatien;
	}
	public void setGiatien(String giatien) {
		this.giatien = giatien;
	}
	public Integer getSoghe() {
		return soghe;
	}
	public void setSoghe(Integer soghe) {
		this.soghe = soghe;
	}
	public Integer getThoigiandi() {
		return thoigiandi;
	}
	public void setThoigiandi(Integer thoigiandi) {
		this.thoigiandi = thoigiandi;
	}
	
	
}
