package com.example.Api;

import java.util.List;

public class AjaxBody {
	String msg;
	List<NhanVien> result;
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public List<NhanVien> getResult() {
		return result;
	}
	public void setResult(List<NhanVien> result) {
		this.result = result;
	} 
	
}
