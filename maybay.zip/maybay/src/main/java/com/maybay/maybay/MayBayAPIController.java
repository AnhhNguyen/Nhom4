package com.maybay.maybay;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;




@RestController
@RequestMapping(value = "/maybay")

public class MayBayAPIController {
	@Autowired
	MayBayService service;
	// 1 Get all maybay
	@RequestMapping(value = "/getThongTinMayBay")
	public List<MayBay2> getThongTinMayBay(@RequestParam(name = "mave") Integer mave) {
		return service.getThongTinMayBay(mave);
	}
		//delete 1chuyen xe theo ma
		@RequestMapping(value = "/deleteMayBayByMaxe")
		public boolean deleteMayBayByMaxe(@RequestBody MayBay mayBay) {
			service.deleteMayBayByMaxe(mayBay.getMave());
			return true;
		}
		//delete nhieu chuyen theo ngay
		@RequestMapping(value = "/deleteManyMayBayByNgay")
		public boolean deleteManyMayBayByNgay(@RequestBody MayBay mayBay) {
			 service.deleteManyMayBayByNgay(mayBay);
			 return true;
		}
		//update
		@RequestMapping(value = "/getOneMayBayByMave")
		public MayBay getOneMayBayByMaxe(@RequestParam(name = "mave") Integer mave) {
			return service.getOneMayBayByMave(mave);
		}
		@RequestMapping(value = "/updateOneMayBayByMave")
		public boolean updateOneMayBayByMave(@RequestBody MayBay MayBay) {
			service.updateOneMayBay(MayBay);
			return true;
		}
		//search
		@RequestMapping(value="/searchngay")
		public @ResponseBody List<MayBay> getnameSinhVien(@RequestParam (name="ngaydi") String ngaydi,@RequestParam (name="noidi") String noidi,@RequestParam (name="noiden") String noiden){
			return service.SearchDate(ngaydi, noidi, noiden);
		}
		@RequestMapping(value = "/maybay")
		public String Maybay(Model model) {
			
			List<MayBay> listmaybay = this.service.getall();
			model.addAttribute("listmaybay", listmaybay);
			return "redirect:/index";
		}
		//e. tìm kiếm các thực thể theo 1 lúc 2 thuộc tính ví dụ: tenSV, diaChi(tên và địa chỉ giống nhau)
		@RequestMapping(value="/timkiemchuyenbay")
		public ResponseEntity<?> searchMayBayTheoMave(@Valid @RequestBody MayBay mayBay, Error errors){

			AjaxBody result = new AjaxBody();

//			if (errors.hasErrors()) {
	//
//	            result.setMsg(errors.getAllErrors().stream().map(x -> x.getDefaultMessage()).collect(Collectors.joining(",")));
//	            return ResponseEntity.badRequest().body(result);
	//
//	        }
	        List<MayBay> mayBays = service.searchMayBayTheoMave(mayBay.mave);
	        if (mayBays.isEmpty()) {
	            result.setMsg("no user found!");
	        } else {
	            result.setMsg("success");
	        }
	        result.setResult(mayBays);

	        return ResponseEntity.ok(result);
		}
		
}
