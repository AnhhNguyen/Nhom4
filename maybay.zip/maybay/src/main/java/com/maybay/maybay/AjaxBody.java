package com.maybay.maybay;

import java.util.List;

public class AjaxBody {
	String msg;
	List<MayBay> result;
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public List<MayBay> getResult() {
		return result;
	}
	public void setResult(List<MayBay> result) {
		this.result = result;
	} 
	
}
