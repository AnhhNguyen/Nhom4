package com.maybay.maybay;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MaybayApplication {

	public static void main(String[] args) {
		SpringApplication.run(MaybayApplication.class, args);
	}

}
